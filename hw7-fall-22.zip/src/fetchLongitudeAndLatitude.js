export function fetchLongitudeAndLatitude(query) {
  // TODO
}
