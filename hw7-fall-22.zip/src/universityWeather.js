import { fetchCurrentWeather } from "./fetchCurrentWeather.js"
import { fetchLongitudeAndLatitude } from "./fetchLongitudeAndLatitude.js"
import { fetchUniversities } from "./fetchUniversities.js"

export function fetchUniversityWeather(query) {
  // TODO
}

export function fetchUMassWeather() {
  // TODO
}

export function fetchUCalWeather() {
  // TODO
}
