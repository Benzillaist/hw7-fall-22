import { fetchCurrentWeather } from "./fetchCurrentWeather"
import { fetchLongitudeAndLatitude } from "./fetchLongitudeAndLatitude"
import { fetchUniversities } from "./fetchUniversities"

export function fetchUniversityWeather() {
  // TODO
}

export function fetchUMassWeather() {
  // TODO
}

export function fetchUCalWeather() {
  // TODO
}
