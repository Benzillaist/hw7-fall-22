export function fetchUniversities(query) {
  // TODO
}
