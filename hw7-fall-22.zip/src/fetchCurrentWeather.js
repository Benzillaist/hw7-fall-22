export function fetchCurrentWeather(longitude, latitude) {
  // TODO
}
