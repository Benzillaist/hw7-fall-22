import { readFile, writeFile } from "node:fs/promises";

export function writeToJSONFile(path, data) {
  // TODO
}

export function readFromJSONFile(path) {
  // TODO
}
